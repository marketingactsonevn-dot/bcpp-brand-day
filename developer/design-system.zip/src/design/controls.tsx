import { useId, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from 'react';
import './controls.css';

export function Icon({name}:{name:'close'|'search'|'chevron'|'info'}) {
  const paths={close:'M4 4l8 8M12 4l-8 8',search:'M11 11l3 3M12 7a5 5 0 1 1-10 0 5 5 0 0 1 10 0',chevron:'m4 6 4 4 4-4',info:'M8 7v5M8 4v.1'};
  return <svg className="ds-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d={paths[name]} stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
export function Button({variant='secondary',className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'secondary'|'primary'|'danger'}) {
  return <button type="button" {...props} className={`ds-button ds-button--${variant} ${className}`}/>;
}
export function IconButton({label,icon='close',className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{label:string;icon?:'close'|'search'|'chevron'|'info'}) {
  return <button type="button" {...props} className={`icon-btn ds-icon-button ${className}`} aria-label={label}><Icon name={icon}/></button>;
}
export function SearchField({label,value,onValueChange,className='',...props}:Omit<InputHTMLAttributes<HTMLInputElement>,'value'|'onChange'|'type'>&{label:string;value:string;onValueChange:(value:string)=>void}) {
  return <label className={`ds-search ${className}`}><Icon name="search"/><input {...props} type="search" aria-label={label} value={value} onChange={e=>onValueChange(e.target.value)}/></label>;
}
export function Segmented<T extends string>({label,value,options,onChange,className=''}:{label:string;value:T;options:{value:T;label:string;disabled?:boolean}[];onChange:(value:T)=>void;className?:string}) {
  return <div className={`ds-segmented ${className}`} role="group" aria-label={label}>{options.map(o=><button type="button" key={o.value} disabled={o.disabled} aria-pressed={o.value===value} onClick={()=>onChange(o.value)}>{o.label}</button>)}</div>;
}
export function Field({label,hint,error,children}:{label:string;hint?:string;error?:string;children:(props:{id:string;'aria-describedby'?:string;'aria-invalid'?:true})=>ReactNode}) {
  const id=useId(),note=error||hint;
  return <div className="ds-field"><label htmlFor={id}>{label}</label>{children({id,'aria-describedby':note?`${id}-note`:undefined,'aria-invalid':error?true:undefined})}{note&&<small id={`${id}-note`} className={error?'ds-error':''} role={error?'alert':undefined}>{note}</small>}</div>;
}

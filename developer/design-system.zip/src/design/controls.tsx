import { useEffect, useId, useRef, type ButtonHTMLAttributes, type CSSProperties, type InputHTMLAttributes, type ReactNode } from 'react';
import './controls.css';

const PATHS = {
  close: 'M4 4l8 8M12 4l-8 8',
  search: 'M11 11l3 3M12 7a5 5 0 1 1-10 0 5 5 0 0 1 10 0',
  chevron: 'm4 6 4 4 4-4',
  info: 'M8 7v5M8 4v.1',
  more: 'M3.5 8h.01M8 8h.01M12.5 8h.01',
  plus: 'M8 3.5v9M3.5 8h9',
  star: 'M8 2.4l1.68 3.42 3.77.55-2.73 2.66.65 3.76L8 11.02l-3.37 1.77.65-3.76-2.73-2.66 3.77-.55z',
} as const;
export type IconName = keyof typeof PATHS;

export function Icon({name}:{name:IconName}) {
  return <svg className={`ds-icon ds-icon--${name}`} viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d={PATHS[name]} stroke="currentColor" strokeWidth={name==='more'?2.4:1.4} strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
export function Button({variant='secondary',className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'secondary'|'primary'|'danger'|'quiet'}) {
  return <button type="button" {...props} className={`ds-button ds-button--${variant} ${className}`}/>;
}
/** `aria-pressed` turns it into a toggle; the star icon fills while pressed. */
export function IconButton({label,icon='close',className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{label:string;icon?:IconName}) {
  return <button type="button" {...props} className={`icon-btn ds-icon-button ${className}`} aria-label={label}><Icon name={icon}/></button>;
}
/** Escape first clears a non-empty query (every engine, not only native search clear) and stops there. */
export function SearchField({label,value,onValueChange,onKeyDown,className='',...props}:Omit<InputHTMLAttributes<HTMLInputElement>,'value'|'onChange'|'type'>&{label:string;value:string;onValueChange:(value:string)=>void}) {
  return <label className={`ds-search ${className}`}><Icon name="search"/><input {...props} type="search" aria-label={label} value={value} onChange={e=>onValueChange(e.target.value)} onKeyDown={e=>{onKeyDown?.(e);if(!e.defaultPrevented&&e.key==='Escape'&&value){e.preventDefault();e.stopPropagation();onValueChange('');}}}/></label>;
}
export function Segmented<T extends string>({label,value,options,onChange,className=''}:{label:string;value:T;options:{value:T;label:string;disabled?:boolean}[];onChange:(value:T)=>void;className?:string}) {
  return <div className={`ds-segmented ${className}`} role="group" aria-label={label}>{options.map(o=><button type="button" key={o.value} disabled={o.disabled} aria-pressed={o.value===value} onClick={()=>onChange(o.value)}>{o.label}</button>)}</div>;
}
export function Field({label,hint,error,children}:{label:string;hint?:string;error?:string;children:(props:{id:string;'aria-describedby'?:string;'aria-invalid'?:true})=>ReactNode}) {
  const id=useId(),note=error||hint;
  return <div className="ds-field"><label htmlFor={id}>{label}</label>{children({id,'aria-describedby':note?`${id}-note`:undefined,'aria-invalid':error?true:undefined})}{note&&<small id={`${id}-note`} className={error?'ds-error':''} role={error?'alert':undefined}>{note}</small>}</div>;
}

export type MenuItem = { label: string; onSelect: () => void; disabled?: boolean; danger?: boolean } | 'separator';
/**
 * Overflow menu: one quiet ⋯ trigger for secondary row actions. Native popover gives top layer, light dismiss,
 * Escape and focus return; arrows/Home/End move between items. Anchored where CSS anchor positioning exists, bottom sheet otherwise.
 */
export function Menu({label,items,className=''}:{label:string;items:MenuItem[];className?:string}) {
  const id=useId(),pop=useRef<HTMLDivElement>(null),anchor=`--menu-${id.replace(/[^a-z0-9]/gi,'')}`;
  const enabled=()=>[...pop.current?.querySelectorAll<HTMLButtonElement>('[role=menuitem]:not(:disabled)')??[]];
  useEffect(()=>{
    const el=pop.current;if(!el)return;
    const toggle=(e:Event)=>{if((e as ToggleEvent).newState==='open')enabled()[0]?.focus();};
    el.addEventListener('toggle',toggle);return()=>el.removeEventListener('toggle',toggle);
  },[]);
  return <>
    <button type="button" className={`icon-btn ds-icon-button ds-menu-trigger ${className}`} aria-label={label} aria-haspopup="menu" popoverTarget={id} style={{anchorName:anchor} as CSSProperties}><Icon name="more"/></button>
    <div id={id} ref={pop} popover="auto" role="menu" aria-label={label} className="ds-menu" style={{positionAnchor:anchor} as CSSProperties} onKeyDown={e=>{
      const list=enabled(),i=list.indexOf(document.activeElement as HTMLButtonElement);
      const to=e.key==='ArrowDown'?i+1:e.key==='ArrowUp'?i-1:e.key==='Home'?0:e.key==='End'?list.length-1:null;
      if(to===null||!list.length)return;
      e.preventDefault();list[(to+list.length)%list.length].focus();
    }}>
      <p className="ds-menu-title" aria-hidden="true">{label}</p>
      {items.map((it,i)=>it==='separator'?<hr key={i} role="separator"/>:<button key={i} type="button" role="menuitem" disabled={it.disabled} className={it.danger?'is-danger':undefined} onClick={()=>{pop.current?.hidePopover();it.onSelect();}}>{it.label}</button>)}
    </div>
  </>;
}

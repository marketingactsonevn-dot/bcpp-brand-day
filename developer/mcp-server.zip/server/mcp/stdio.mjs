#!/usr/bin/env node
import { serveStdio } from '@modelcontextprotocol/server/stdio';
import { createBrandServer } from './server.mjs';
const instances=new Set();
const handle=serveStdio(()=>{const instance=createBrandServer();instances.add(instance);return instance.server;});
async function close(){await Promise.allSettled([...instances].map(i=>i.close()));await handle.close();}
process.once('SIGINT',()=>{void close();});
process.once('SIGTERM',()=>{void close();});

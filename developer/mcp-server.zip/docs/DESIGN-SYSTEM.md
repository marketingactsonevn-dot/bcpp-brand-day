# Brand Image Studio — Design System 1.0

English reference, 19 October 2026. Full documentation: https://marketingactsonevn-dot.github.io/bcpp-brand-day/developer/design-system.html
Interactive catalog: https://marketingactsonevn-dot.github.io/bcpp-brand-day/?view=design-system

Preserve the approved warm-paper studio, scrapbook album, brand logos and image colors. Use Newsreader for editorial headings, Be Vietnam Pro for body/controls and JetBrains Mono for brief metadata.

Source of truth: src/design/tokens.css, controls.tsx and controls.css. Primitives define values; semantic tokens define roles. Existing --bg/ink/muted/line/card/wash aliases apply the same foundation throughout the app.

- Page #F5F3F0; panel #FFFEFC; text #191918; secondary text #68665F; subtle border #E3E0DA.
- Spacing: 4, 8, 12, 16, 20, 24, 32, 40, 48px. Header-to-divider gap at least 16px.
- Type: 11/12/14/16px, titles 28–38px; body line-height 1.55.
- Radii: 6/10/16/28/pill. Low/panel/popover shadows identify layers.
- Controls: 32px compact, 36px standard, 44px touch. Visible charcoal keyboard focus. Error states need text, not color alone.
- Motion: 140/220ms, zero under reduced-motion preference.

Reusable controls: Button (secondary/primary/danger), IconButton (required accessible label), SearchField, Segmented (aria-pressed, optional disabled options), Field (linked label/hint/error). Preserve existing Dialog, CrewPicker, GroupPicker, LibraryPanel and planner business logic.

Check default, hover, focus, active, disabled and error states. Native button type defaults to button. Use semantic labels and aria-invalid/aria-describedby. Do not hide actionable errors in tooltips.

Responsive: up to 600px, 16px panel gutters and stacked fields; 601–980px tablet; above 980px desktop. Wrap toolbar groups instead of shrinking icons. Keep overlays inside the viewport. Linked products use at most four columns. Kit avatars stay 56px wide; plan/PDF photo frames stay 3:4. Long fitting notes scroll inside a stable detail area so pagination does not change unexpectedly.

Before extending: reuse existing components/tokens, preserve callbacks/state/API and source data, run affected regressions, inspect real screenshots. Do not infer unknown product shades. Geometry checks are not visual acceptance or full accessibility certification. No dark theme is included.

# Brand Image Studio — Design System 1.1

English reference, 27 October 2026. Full documentation: https://marketingactsonevn-dot.github.io/bcpp-brand-day/developer/design-system.html
Interactive catalog: https://marketingactsonevn-dot.github.io/bcpp-brand-day/?view=design-system

Source of truth: src/design/tokens.css, controls.tsx and controls.css. Primitives define values; semantic tokens define roles. Product rules live in the app specification, not here.

## Principles

1. Photography first: warm paper, charcoal ink, scrapbook album. Never recolor photos or logos; no decorative gradients in forms; no gray card behind every product.
2. Editorial restraint: Newsreader for headings, Be Vietnam Pro for body and controls, uppercase JetBrains Mono for short metadata. Brand accent is decoration only, never the focus ring.
3. A row shows at most two visible controls. Primary actions stay visible; secondary actions (reorder, remove, framing) live in a ⋯ menu. A thumbnail is itself the button when it is the object being changed.
4. Quiet fields read like text until hover/focus. Controls that must be recognised as controls use --border-control (at least 3:1).
5. Size by input device: 44px touch targets under pointer: coarse, not by window width.
6. Every state has words: errors, warnings and success include text near the action, never color or a tooltip alone.

## Tokens

- Surfaces: page #F5F3F0, panel #FFFEFC, album #FBFAF7, subtle #EFECE7, highlight #FBF3E8.
- Text: primary #191918, secondary #68665F (at least 4.88:1 on every surface). Placeholders use the secondary color at full opacity.
- Borders: subtle #E3E0DA for dividers; control #8A8479 for boundaries (at least 3:1). All borders are 1px; dashed only for an empty slot that can be filled.
- Type: 11/12/14/16px, titles 28–38px, body line height 1.55. Floor: sentence text at least 11px, uppercase mono labels at least 10px.
- Spacing: 4, 8, 12, 16, 20, 24, 32, 40, 48px.
- Controls: 32 compact (in-row tools, chips), 36 default, 44 touch.
- Radius: 6 (small photos, menu items), 10 (controls), 16 (popovers), 28 (panels), pill.
- Elevation: low (active segment), panel (large floating layers), popover (menus and small pickers).
- Layers: --z-raised 1, overlay 6, dropdown 20, notice 30, sheet 40, toast 60, popover 80, context 1000. Native dialog and popover elements use the top layer.
- Motion: 140/220ms with --ease-standard cubic-bezier(.2,0,0,1); zero under reduced motion.
- Breakpoints (literal in media queries): 480 narrow phone, 600 phone, 980 tablet; touch uses (pointer: coarse).
- Image frames: --frame-aspect 3 / 4 for every plan and PDF frame; kit thumbnails 56px (48px below 480px).

Compatibility aliases (--bg, --ink, --muted, --line, --card, --wash, --serif, --sans, --mono, --shadow-card, --ctl, --ok, --warn, --err) map to semantic tokens. When overriding locally, set both the semantic token and its alias, because custom properties inherit computed values. New code uses semantic names only.

## Components

- Button: secondary, primary, danger, quiet; default, hover, active, focus-visible, disabled, aria-pressed. Default type is button.
- IconButton: required label naming the object (for example "Key product: <name>"); aria-pressed turns it into a toggle and fills the star icon.
- Icon: close, search, chevron, info, more, plus, star; 16px currentColor, stroke 1.4.
- Menu: one ⋯ trigger, items {label, onSelect, disabled?, danger?} and separators. Native popover gives light dismiss, Escape and focus return; arrow keys, Home and End move between items; the first item receives focus. Anchored to the trigger, a bottom sheet with a title at 600px and below. Destructive items go last in the error color.
- SearchField, Segmented (aria-pressed buttons, no fake tab/radio roles), Field (linked label, hint, error with aria-invalid and aria-describedby).
- Real radiogroups and tablists use the shared rovingKeys keyboard model: one Tab stop on the checked item, arrow keys with wrap, Home/End, selection follows focus; tabs point to their tabpanel with aria-controls.
- Existing domain components (Dialog, Help, ShadeSelect, GroupPicker, ProductPicker, CrewPicker, DatePicker, LibraryPanel, Kit, Calendar, Album) keep their specialised logic and share the semantic tokens. Popover surfaces use panel background, subtle border, 16px radius and popover elevation.

## Patterns

- List row with a photo (product kit): 3:4 56px packshot button (dashed empty slot with +), name plus uppercase mono meta, shade chip, quiet auto-growing note, Key star and ⋯ on the right. Several shades of one product form a group: a head with name, shade count, shade picker and reorder menu, then one row per shade with its own packshot, note and Key.
- Progressive disclosure: rarely used actions in ⋯; disabled items stay visible to explain why.
- Navigation context lives in the URL; Back and in-app "back" buttons give the same result; Escape in a search box only clears or closes that box.
- Create/edit: dialogs for save/cancel decisions; double submits are prevented with idempotency keys (UUIDs work on plain-HTTP LAN origins too).
- Autosave: only changed fields are sent with their base value; offline retries when online; conflicts show "keep mine / use theirs"; leaving a screen during a save still completes it. Save labels reflect real persistence.
- Upload, crop and export: JPEG/PNG/WebP up to 25MB with preview; 3:4 framing with drag and 1–4× zoom; export waits for unsaved edits and reports missing photos or information.
- Destructive actions are recoverable where the data model allows (soft-deleted looks, undo toast) and otherwise sit at the end of a menu.

## Content

- Strings live in the app's VI/EN string tables; components do not inline language ternaries.
- Keep proper names, product names and source shade/edition codes. Never infer a shade from a photo; show "No shade chosen" instead.
- Dates are day-first and use Vietnam time (Asia/Ho_Chi_Minh) for shoot days.
- Long names wrap in lists and headings; truncate only inside one-line controls and expose the full text in a title.
- Logos, model photos and transparent assets keep their aspect ratio and alpha; no gray backdrop behind packshots.

## Review checklist

Type check, affected unit tests and browser regressions in a fresh profile; real screenshots at desktop, tablet and phone (touch); hover, focus, disabled, error, both languages, long names, many shades, empty and error states; text contrast at least 4.5:1, control boundaries at least 3:1, 44px touch targets, reduced motion. Geometry checks do not replace visual review.

The source download contains the token, control and catalog files plus this reference. It is a reference module for the existing React app, not a standalone application; it expects the app fonts and global icon-button styles.
